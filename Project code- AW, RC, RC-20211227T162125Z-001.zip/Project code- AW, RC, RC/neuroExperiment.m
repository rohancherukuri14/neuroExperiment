audioToImageMap = containers.Map({'bed.mp3', 'cat.mp3', 'cup.mp3', 'dog.mp3', 'door.mp3', 'eye.mp3', 'pen.mp3', 'shoe.mp3', 'tree.mp3', 'watch.mp3', 'moon.mp3', 'cape.mp3', 'field.mp3', 'mat.mp3', 'goat.mp3', 'fig.mp3', 'bee.mp3', 'eel.mp3', 'fish.mp3', 'pie.mp3', 'ring.mp3', 'cake.mp3', 'cheese.mp3', 'pool.mp3', 'crate.mp3', 'fan.mp3', 'leaf.mp3', 'leash.mp3', 'hand.mp3', 'lime.mp3', 'spoon.mp3', 'rock.mp3'} ...
                                ,{'bed.png', 'cat.png', 'cup.png', 'dog.png', 'door.png', 'eye.png', 'pen.png', 'shoe.png', 'tree.png', 'watch.png', 'moon.png', 'cape.png', 'field.png', 'mat.png', 'goat.png', 'fig.png', 'bee.png', 'eel.png', 'fish.png', 'pie.png', 'ring.png', 'cake.png', 'cheese.png', 'pool.png', 'crate.png', 'fan.png', 'leaf.png', 'leash.png', 'hand.png', 'lime.png', 'spoon.png', 'rock.png'});

images = ["bed.png", "cat.png", "cup.png", "dog.png","door.png", "eye.png", "pen.png", "shoe.png", "tree.png", "watch.png", "moon.png", "cape.png", "field.png", "mat.png", "goat.png", "fig.png", "bee.png", "eel.png", "fish.png", "pie.png", "ring.png", "cake.png", "cheese.png", "pool.png", "crate.png", "fan.png", "leaf.png", "leash.png", "hand.png", "lime.png", "spoon.png", "rock.png"];
disp("Please read the contents of instructions.txt before you continue");
disp("Once you have read the instructions, type l if you are left-hand dominant or r if you are right");
k = waitforbuttonpress;
handedness = double(get(gcf,'CurrentCharacter'));
total_start_time = datestr(now, 'dd-mm-yyyy HH:MM:SS FFF');
chooseFrom = [1 2 3 4];
% if value == 108
%     inputButtons = [49 50 51 52];
% elseif value == 114
%     inputButtons = [55 56 57 48];
% end
inputButtons = [49 50 51 52];
left_audio_count = 0;
right_audio_count = 0;
trial_count = 0;
curr_hand = 108;
reaction_times = double.empty(0, 32);
earChoice = string.empty(0, 32);
correctAnswer = double.empty(0, 32);
dHand_dEar = double.empty(0, 8);
dHand_ndEar = double.empty(0, 8);
ndHand_dEar = double.empty(0, 8);
ndHand_ndEar = double.empty(0, 8);
dHdECount = 1;
dHndECount = 1;
ndHdECount = 1;
ndHndECount = 1;
while trial_count < 32
    if left_audio_count == 8
        temp = 2;
    elseif right_audio_count == 8
        temp = 1;
    else
        temp = randi(2);
    end
    audioFile = char(randsample(keys(audioToImageMap), 1));
    imageFile = audioToImageMap(audioFile);
    remove(audioToImageMap, audioFile);
    imageCopy = images(images ~= imageFile);
    otherOptionFiles = randsample(imageCopy, 3, false);
    [X1,map1]=imread(imageFile);
    [X2,map2]=imread(char(otherOptionFiles(1)));
    [X3,map3]=imread(char(otherOptionFiles(2)));
    [X4,map4]=imread(char(otherOptionFiles(3)));
    plotOrder = randsample(chooseFrom, 4, false);
    figure(1);
    subplot(1,4,plotOrder(1)), imshow(X1,map1)
    subplot(1,4,plotOrder(2)), imshow(X2,map2)
    subplot(1,4,plotOrder(3)), imshow(X3,map3)
    subplot(1,4,plotOrder(4)), imshow(X4,map4)
    [data, fs] = audioread(audioFile);
    silence = zeros(size(data));
    if temp == 1
        out = [data, silence].';
        left_audio_count = left_audio_count + 1;
        ear_choice = 108;
    else
        out = [silence, data(:)].';
        right_audio_count = right_audio_count + 1;
        ear_choice = 114;
    end
    sound(out, fs);
    start_time = datestr(now, 'dd-mm-yyyy HH:MM:SS FFF');
    k = waitforbuttonpress;
    end_time = datestr(now, 'dd-mm-yyyy HH:MM:SS FFF');
    value = double(get(gcf,'CurrentCharacter'));
    difference = end_time - start_time;
    seconds = difference(end - 4);
    hundreds = difference(end - 2);
    tens = difference(end - 1);
    ones = difference(end);
    if ones < 0
        ones = 10 + ones;
        tens = tens - 1;
    end
    if tens < 0
        tens = 10 + tens;
        hundreds = hundreds - 1;
    end
    if hundreds < 0
        hundreds = 10 + hundreds;
        seconds = seconds - 1;
    end
    if seconds < 0
        seconds = 10 + seconds;
    end
    reaction_time = seconds + 0.1 * hundreds + 0.01 * tens + 0.001 * ones;
    if plotOrder(1) == find(inputButtons == value)
        if ear_choice == handedness
            if curr_hand == handedness
                dHand_dEar(dHdECount) = reaction_time;
                dHdECount = dHdECount + 1;
            else
                ndHand_dEar(ndHdECount) = reaction_time;
                ndHdECount = ndHdECount + 1;
            end
        else
            if curr_hand == handedness
                dHand_ndEar(dHndECount) = reaction_time;
                dHndECount = dHndECount + 1;
            else
                ndHand_ndEar(ndHndECount) = reaction_time;
                ndHndECount = ndHndECount + 1;
            end
        end
    end
    trial_count = trial_count + 1;
    if trial_count == 16
        disp("Now switch to your right hand. Control buttons are 7, 8, 9, and 0. Press enter to continue.");
        inputButtons = [55 56 57 48];
        left_audio_count = 0;
        right_audio_count = 0;
        curr_hand = 114;
        k = waitforbuttonpress;
    end
end    
save output dHand_dEar ndHand_dEar dHand_ndEar ndHand_ndEar